// Function to calculate age
function getDOB() {
  const dob = new Date(document.getElementById('inputDob').value);
  const today = new Date(document.getElementById('cdate').value || new Date());
  let age = today.getFullYear() - dob.getFullYear();
  const monthDiff = today.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age--;
  }
  document.getElementById('currentAge').textContent = `Your Age is: ${age}`;
}

// Function to calculate BMI with height in inches
function calculateBMI() {
  const heightInches = parseFloat(document.getElementById('height').value); // Input height in inches
  const weightKg = parseFloat(document.getElementById('weight').value); // Input weight in kilograms
  
  if (!heightInches || !weightKg) {
      document.getElementById('bmiResult').textContent = "Please enter both height and weight!";
      return;
  }
  
  // Convert height from inches to meters (1 inch = 0.0254 meters)
  const heightMeters = heightInches * 0.0254;
  
  // Calculate BMI using meters and kilograms
  const bmi = (weightKg / (heightMeters * heightMeters)).toFixed(2);
  
  let bmiCategory = '';
  if (bmi < 18.5) {
      bmiCategory = 'Underweight';
  } else if (bmi >= 18.5 && bmi < 24.9) {
      bmiCategory = 'Normal weight';
  } else if (bmi >= 25 && bmi < 29.9) {
      bmiCategory = 'Overweight';
  } else {
      bmiCategory = 'Obese';
  }

  document.getElementById('bmiResult').textContent = `Your BMI is: ${bmi} (${bmiCategory})`;
}

